#!/bin/bash
python3 agentzero_ui.py